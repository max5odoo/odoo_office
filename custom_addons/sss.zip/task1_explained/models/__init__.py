# -*- coding: utf-8 -*-

# from . import models
# from . import student
from . import abstract
from . import student_details
from . import course_details
from . import batch_details
from . import registration_details
from . import professor_details


